import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/80 backdrop-blur-xl border-b border-border" : ""
      }`}
    >
      <div className="container mx-auto flex items-center justify-between py-5 px-6">
        <Link to="/" className="font-heading text-lg font-semibold tracking-tight">
          <span className="text-gradient-primary">MVC</span>
          <span className="text-muted-foreground font-light">.ux</span>
        </Link>
        <div className="flex items-center gap-8">
          <Link
            to="/"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              location.pathname === "/" ? "text-primary" : "text-muted-foreground"
            }`}
          >
            Inicio
          </Link>
          <Link
            to="/proyecto/santander-officebanking"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              location.pathname.includes("proyecto") ? "text-primary" : "text-muted-foreground"
            }`}
          >
            Proyectos
          </Link>
          <a
            href="mailto:contacto@mvc-ux.dev"
            className="text-sm font-medium bg-gradient-primary text-primary-foreground px-5 py-2 rounded-full hover:opacity-90 transition-opacity"
          >
            Contacto
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
